package com.rina.home_3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.darsh.multipleimageselect.activities.AlbumSelectActivity;
import com.darsh.multipleimageselect.helpers.Constants;
import com.darsh.multipleimageselect.models.Image;
import com.google.gson.JsonObject;
import com.rina.home_3.DefaultURL.GeneratorUrl;
import com.rina.home_3.network.ApiDataCompromiser;
import com.rina.home_3.network.RestuarantsController;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UploadMulImageActivity extends AppCompatActivity {
    private Button btnUploadMenu;
    private ArrayList<Image> menuImageList;
    private ArrayList<Image> resturantImageList;
    private int menuImageCode = 1;
    private int resturantImageCode = 2;
    private EditText edResturantName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_mul_image);
        btnUploadMenu = (Button)findViewById(R.id.btnUploadMenu);
        edResturantName = (EditText)findViewById(R.id.edResturantName);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d("ddd", "onActivityResult: "+requestCode);
        if (requestCode == menuImageCode && resultCode == RESULT_OK && data != null) {
            menuImageList = data.getParcelableArrayListExtra(Constants.INTENT_EXTRA_IMAGES);
            Log.d("---------->>>>>>", "onActivityResult: "+ menuImageList.get(0).path);
        }
        else if (requestCode == resturantImageCode && resultCode == RESULT_OK && data != null) {
            resturantImageList = data.getParcelableArrayListExtra(Constants.INTENT_EXTRA_IMAGES);
            Log.d("---------->>>>>>", "onActivityResult: "+resturantImageList.size());
        }
    }

    public void uploadImage(View view) {
        Intent intent = new Intent(this, AlbumSelectActivity.class);
        intent.putExtra(Constants.INTENT_EXTRA_LIMIT, 5);
        startActivityForResult(intent, menuImageCode);
        btnUploadMenu.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0,R.drawable.ic_done_white);
    }


    public void UploadResturantImage(View view) {
        Intent intent = new Intent(this, AlbumSelectActivity.class);
        intent.putExtra(Constants.INTENT_EXTRA_LIMIT, 5);
        startActivityForResult(intent,resturantImageCode);
    }

    public void PostData(View view){
        RestuarantsController resturanController = ApiDataCompromiser.
                                        createService( RestuarantsController.class,
                                        GeneratorUrl.API_KEY_RESTURANTS.toString(),
                                        GeneratorUrl.URL_API_RESTURANT.toString());

        Map<String,String> map = new HashMap<String, String>();
            map.put("NAME",edResturantName.getText().toString());

        Call<JsonObject> call = resturanController.setNewResturant(map,getMenu(),getResurant());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                Log.d("response", "onResponse: "+response.body());
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.d("Onfalure", "onFailure: "+t.getLocalizedMessage() );

            }
        });

    }

    ArrayList<MultipartBody.Part> getMenu(){
        RequestBody requestFile = null;
        ArrayList<MultipartBody.Part> menu = new ArrayList<>();
        MultipartBody.Part bodyImage = null;
        for ( Image im :  resturantImageList){
            requestFile = RequestBody.create( MediaType.parse("multipart/form-data"),im.path );
            bodyImage = MultipartBody.Part.createFormData("MENU", im.name,requestFile);
            menu.add(bodyImage);
        }
        return menu;
    }
    ArrayList<MultipartBody.Part> getResurant(){
        RequestBody requestFile = null;
        ArrayList<MultipartBody.Part> menu = new ArrayList<>();
        MultipartBody.Part bodyImage = null;
        for ( Image im :  resturantImageList){
             requestFile = RequestBody.create( MediaType.parse("multipart/form-data"),im.path );
             bodyImage = MultipartBody.Part.createFormData("RESTAURANT", im.name,requestFile);
            menu.add(bodyImage);
        }
        return menu;
    }


}
