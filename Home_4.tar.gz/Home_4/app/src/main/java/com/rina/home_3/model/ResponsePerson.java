package com.rina.home_3.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rina on 11/30/16.
 */

public class ResponsePerson {
    @SerializedName("CODE")
    public String CODE;
    @SerializedName("MESSAGE")
    public String MESSAGE;
    @SerializedName("DATA")
    public ArrayList<Person> Person;
    @SerializedName("PAGINATION")
    public PAGINATION PAGINATION;


    public static class PAGINATION {
        @SerializedName("PAGE")
        public int PAGE;
        @SerializedName("LIMIT")
        public int LIMIT;
        @SerializedName("TOTAL_COUNT")
        public int TOTAL_COUNT;
        @SerializedName("TOTAL_PAGES")
        public int TOTAL_PAGES;
    }
}
