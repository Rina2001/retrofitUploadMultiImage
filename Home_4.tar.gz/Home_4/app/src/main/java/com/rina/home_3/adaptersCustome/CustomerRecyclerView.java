package com.rina.home_3.adaptersCustome;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.rina.home_3.R;
import com.rina.home_3.model.Person;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by ppsc08 on 30-Nov-16.
 */

public class CustomerRecyclerView extends RecyclerView.Adapter<ViewHolder> {
    ArrayList<Person> arrayList;
    Context context;
    public CustomerRecyclerView(ArrayList<Person> arrayList,Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.
                from(parent.getContext())
                .inflate(R.layout.customer_user_list,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.lblUsername.setText(arrayList.get(position).getNAME());
        holder.lblEmail.setText(arrayList.get(position).getEMAIL());
        holder.lblPhone.setText(arrayList.get(position).getTELEPHONE());

        Picasso
                .with(context)
                .load(arrayList.get(position).getIMAGE_URL())
                .resize(160,160)
                .into(holder.imageUser);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }
}
