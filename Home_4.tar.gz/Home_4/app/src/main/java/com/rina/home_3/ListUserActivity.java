package com.rina.home_3;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.google.gson.annotations.SerializedName;
import com.rina.home_3.DefaultURL.GeneratorUrl;
import com.rina.home_3.adaptersCustome.CustomerRecyclerView;
import com.rina.home_3.model.Person;
import com.rina.home_3.model.ResponsePerson;
import com.rina.home_3.network.ApiDataCompromiser;
import com.rina.home_3.network.PersonController;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListUserActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_user);
        recyclerView = (RecyclerView)findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        getListUser();
    }
    void getListUser(){
        PersonController personController = ApiDataCompromiser.createService(PersonController.class,
                                                                     GeneratorUrl.API_KEY_NEWS.toString(),
                                                                     GeneratorUrl.URL_API_NEWS.toString());
        Call<ResponsePerson> call = personController.getUserList(1,50);

        call.enqueue(new Callback<ResponsePerson>() {
            @Override
            public void onResponse(Call<ResponsePerson> call, Response<ResponsePerson> response) {
                recyclerView.setAdapter(new CustomerRecyclerView(response.body().Person,getApplicationContext()));
            }

            @Override
            public void onFailure(Call<ResponsePerson> call, Throwable t) {

            }
        });

    }
}

