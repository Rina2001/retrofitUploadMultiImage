package com.rina.home_3.adaptersCustome;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.rina.home_3.R;

/**
 * Created by rina on 11/30/16.
 */

public class ViewHolder extends RecyclerView.ViewHolder {


    protected ImageView imageUser;
    protected TextView lblUsername;
    protected  TextView lblEmail;
    protected  TextView lblPhone;

    public ViewHolder(View view) {
        super(view);
        imageUser = (ImageView) view.findViewById(R.id.imageUserList);
        lblEmail = (TextView)view.findViewById(R.id.lblUsername);
        lblUsername = (TextView)view.findViewById(R.id.lblUsername);
        lblPhone = (TextView)view.findViewById(R.id.lblPhoneNumber);
    }
}
