package com.rina.home_3;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.wang.avi.AVLoadingIndicatorView;

public class MainActivity extends AppCompatActivity {
    AVLoadingIndicatorView avLoadingIndicatorView;
    TextView lblLoading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        avLoadingIndicatorView = (AVLoadingIndicatorView)findViewById(R.id.personAvLoading);
               PersonActivity();
        }

    private  void PersonActivity(){
        lblLoading=(TextView)findViewById(R.id.lblLoading);

        try{
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    showAvloading();
                    Intent intent = new Intent(MainActivity.this,RegisterPersonActivity.class);
                    startActivity(intent);
                }
            },3000);
            avLoadingIndicatorView.hide();
        }catch (Exception e){}

    }
    void  showAvloading(){

        avLoadingIndicatorView.setIndicator("Loading ");
        avLoadingIndicatorView.setVisibility(View.VISIBLE);
        avLoadingIndicatorView.show();
    }

}
