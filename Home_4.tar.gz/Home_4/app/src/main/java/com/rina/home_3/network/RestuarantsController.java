package com.rina.home_3.network;

import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

/**
 * Created by ppsc08 on 02-Dec-16.
 */

public interface RestuarantsController {
    @Multipart
    @POST("/v1/api/admin/restaurants/multiple/register/test")
    Call<JsonObject> setNewResturant(@QueryMap Map<String,String> name,
                                     @Part ArrayList<MultipartBody.Part> photo,
                                     @Part ArrayList<MultipartBody.Part> rest
                                     ); /* @PartMap  Map<String,RequestBody>  menu,
                                      @PartMap  Map<String,RequestBody> resturant*/
}
