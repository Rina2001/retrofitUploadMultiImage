package com.rina.home_3;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.rina.home_3.DefaultURL.GeneratorUrl;
import com.rina.home_3.network.ApiDataCompromiser;
import com.rina.home_3.network.PersonController;
import com.wang.avi.AVLoadingIndicatorView;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterPersonActivity extends AppCompatActivity {

    private EditText edEmail;
    private EditText edPassword;
    private EditText edUsername;
    private EditText edPhone;
    private Spinner spinnerGender;
    private EditText edFacebookId;
    private ImageView imgUserProfile;
    private  static  int result_image=1;
    Uri data;
    File pictureDir;
    String picturePath;
    AVLoadingIndicatorView avLoadingIndicatorView;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_person);
        RegisterPersonActivity.verifyStoragePermissions(this);

        avLoadingIndicatorView = (AVLoadingIndicatorView)findViewById(R.id.personAvLoading);
            avLoadingIndicatorView.hide();

        edEmail = (EditText)findViewById(R.id.edEmail);
        edPassword = (EditText)findViewById(R.id.edPassword);
        edUsername = (EditText)findViewById(R.id.edUsername);
        edPhone = (EditText)findViewById(R.id.edPhone);
        edFacebookId = (EditText)findViewById(R.id.edFacebookId);
        spinnerGender = (Spinner)findViewById(R.id.spinGender);

        imageUserProfile();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ( requestCode == result_image && resultCode == RESULT_OK ){
            if ( data != null ) {
                try {
                    /*inputStream = getContentResolver().openInputStream(imageIO);
                    */
                    Uri selectedImage = data.getData();
                    String[] filePathColumn = { MediaStore.Images.Media.DATA };

                    Cursor cursor = getContentResolver().query(selectedImage,
                            filePathColumn, null, null, null);
                    cursor.moveToFirst();

                    int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                   picturePath = cursor.getString(columnIndex);
                    cursor.close();

                    imgUserProfile.setImageBitmap(BitmapFactory.decodeFile(picturePath));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
         }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.save,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch ( item.getItemId() ){
            case R.id.action_save:
                //Image
                if (validation() == true) {
                   if(picturePath != null){
                        uploadImage(new File(picturePath));
                  }else{
                        Toast.makeText(getApplicationContext(),"Please Browse Image file",Toast.LENGTH_SHORT);
                   }
                 }
                break;
            case R.id.action_list_user:
                            Intent intent = new Intent(RegisterPersonActivity.this, ListUserActivity.class);
                            startActivity(intent);
                break;
        }
        return  true;
    }


    private void imageUserProfile(){
        imgUserProfile=(ImageView)findViewById(R.id.imgUser);
        imgUserProfile.setImageResource(R.drawable.ic_person_red_a400_48dp);
        imgUserProfile.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.
                                                               Images.Media.
                                                               EXTERNAL_CONTENT_URI);

                pictureDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                pictureDir.getParentFile().mkdirs();
                 picturePath = pictureDir.getPath();
               data = Uri.parse(picturePath);
                intent.setDataAndType(data, "image/*");
                startActivityForResult(intent,result_image);

                return true;
            }
        });

    }
    void uploadImage(File file){
            showAvloading();

            PersonController personController = ApiDataCompromiser.
                                                createService( PersonController.class,
                                                               GeneratorUrl.API_KEY_NEWS.toString(),
                                                               GeneratorUrl.URL_API_NEWS.toString());

            RequestBody requestFile = RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    file );


            MultipartBody.Part bodyImage = MultipartBody.Part.createFormData("PHOTO", file.getName(),requestFile);

            Map<String,String> map = new HashMap<>();

            map.put("NAME",edUsername.getText().toString());
            map.put("EMAIL",edEmail.getText().toString());
            map.put("PASSWORD",edPassword.getText().toString());
            map.put("TELEPHONE",edPhone.getText().toString());
            map.put("GENDER",spinnerGender.getSelectedItem().toString());
            map.put("FACEBOOK_ID",edFacebookId.getText().toString());


            Call<JsonObject> call = personController.addPerson(map,bodyImage);
            call.enqueue(new Callback<JsonObject>() {
                @Override
                public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                    Log.d("RINA",response.message());
                    Toast.makeText(getApplicationContext(),"Successfull",Toast.LENGTH_SHORT).show();
                    avLoadingIndicatorView.hide();
                    clear();
                }
                @Override
                public void onFailure(Call<JsonObject> call, Throwable t) {
                    Log.d("RINA",t.getMessage());
                }
            });


    }

    /**
     *@Methd Validate data
     * @return true if validate is match, otherwise false
     */
    boolean validation(){
        if (TextUtils.isEmpty(edEmail.getText())){
            edEmail.setError("Empty Email!");
            return false;
        }
        else{
            if ( ! Patterns.EMAIL_ADDRESS.matcher(edEmail.getText()).matches()){
                edEmail.setError("Invalid Email");
                return false;
            }
            else  if (!edEmail.getText().toString().contains("gmail") &&
                      !edEmail.getText().toString().contains("yahoo")
                     ){

                edEmail.setError(" Email Server type");
                return false;
            }
        }
        //usernmae
        if ( TextUtils.isEmpty(edUsername.getText()) ){
            edUsername.setError("Empty Username!");
            return false;
        }
        else{
            if ( !Pattern.matches("^[a-zA-Z0-9._-]{3,}$",edUsername.getText())){
                edUsername.setError("Invalid Username");
                return false;
            }
        }
        //Password
        if ( TextUtils.isEmpty(edPassword.getText()) ){
            edPassword.setError("Password is empty!");
            return false;
        }
        else{
            if ( !Pattern.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$",
                            edPassword.getText()) ){
                edPassword.setError("character, digit, lower case , upper case , special sign, no space");
                return false;
            }
        }
        //Phone
        if ( TextUtils.isEmpty(edPhone.getText()) ){
            edPhone.setError("Number Phone is Empty");
            return false;
        }
        else{
            if ( !Patterns.PHONE.matcher(edPhone.getText()).matches() ){
                edPhone.setError("Phone Number is not valid");
                return false;
            }
        }

        //Facebook id
            if (TextUtils.isEmpty(edFacebookId.getText())){
                edFacebookId.setError("Facebook id is empty");
                return false;
            }
        return true;
    }
    /**
     *@Methd Clear View data
     * @return true if validate is match, otherwise false
     */
    boolean clear(){
        edUsername.setText("");
        edEmail.setText("");
        edFacebookId.setText("");
        edPassword.setText("");
        edPhone.setText("");
        imgUserProfile.setImageResource(R.drawable.ic_person_red_a400_48dp);
        return true;
    }

    void  showAvloading(){
        avLoadingIndicatorView.setIndicator("Loading ");
        avLoadingIndicatorView.setVisibility(View.VISIBLE);
        avLoadingIndicatorView.show();
    }


    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    /**
     * Checks if the app has permission to write to device storage
     *
     * If the app does not has permission then the user will be prompted to grant permissions
     *
     * @param activity
     */
    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }

}
