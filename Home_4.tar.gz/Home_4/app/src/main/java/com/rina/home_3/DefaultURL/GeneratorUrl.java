package com.rina.home_3.DefaultURL;

/**
 * Created by ppsc08 on 28-Nov-16.
 */

public enum GeneratorUrl {

    URL_API_NEWS("http://120.136.24.174:1301"),
    URL_API_RESTURANT("http://120.136.24.174:15020"),
    API_KEY_NEWS("Basic QU1TQVBJQURNSU46QU1TQVBJUEBTU1dPUkQ="),
    API_KEY_RESTURANTS("Basic cmVzdGF1cmFudEFETUlOOnJlc3RhdXJhbnRQQFNTV09SRA==");

    private final String text;

    GeneratorUrl(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }
}
